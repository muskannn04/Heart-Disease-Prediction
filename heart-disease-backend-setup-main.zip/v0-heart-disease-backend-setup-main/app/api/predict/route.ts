import { type NextRequest, NextResponse } from "next/server"
import { modelManager, type PredictionInput } from "@/lib/models/model-manager"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { input, modelType = "random_forest" } = body

    // Validate input
    const validation = modelManager.validateInput(input)
    if (!validation.isValid) {
      return NextResponse.json(
        {
          success: false,
          error: "Invalid input data",
          details: validation.errors,
        },
        { status: 400 },
      )
    }

    // Make prediction
    const result = await modelManager.predict(input as PredictionInput, modelType)

    return NextResponse.json({
      success: true,
      data: result,
      message: "Prediction completed successfully",
    })
  } catch (error) {
    console.error("Error making prediction:", error)
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : "Failed to make prediction",
      },
      { status: 500 },
    )
  }
}
