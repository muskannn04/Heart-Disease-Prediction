import { type NextRequest, NextResponse } from "next/server"
import { AuthService } from "./jwt"

export function withAuth(handler: Function, requiredRole?: "patient" | "doctor") {
  return async (request: NextRequest) => {
    try {
      const authHeader = request.headers.get("authorization")
      if (!authHeader || !authHeader.startsWith("Bearer ")) {
        return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
      }

      const token = authHeader.substring(7)
      const payload = AuthService.verifyToken(token)

      if (!payload) {
        return NextResponse.json({ error: "Invalid token" }, { status: 401 })
      }

      if (requiredRole && payload.role !== requiredRole) {
        return NextResponse.json({ error: "Insufficient permissions" }, { status: 403 })
      }

      // Add user info to request
      const requestWithUser = request as NextRequest & { user: typeof payload }
      requestWithUser.user = payload

      return handler(requestWithUser)
    } catch (error) {
      return NextResponse.json({ error: "Authentication failed" }, { status: 401 })
    }
  }
}
