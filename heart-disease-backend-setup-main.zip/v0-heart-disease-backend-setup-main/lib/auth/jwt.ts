import jwt from "jsonwebtoken"
import bcrypt from "bcryptjs"

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key"
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || "7d"

export interface JWTPayload {
  userId: string
  email: string
  role: "patient" | "doctor"
  iat?: number
  exp?: number
}

export class AuthService {
  static async hashPassword(password: string): Promise<string> {
    const saltRounds = 12
    return bcrypt.hash(password, saltRounds)
  }

  static async comparePassword(password: string, hashedPassword: string): Promise<boolean> {
    return bcrypt.compare(password, hashedPassword)
  }

  static generateToken(payload: Omit<JWTPayload, "iat" | "exp">): string {
    return jwt.sign(payload, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN })
  }

  static verifyToken(token: string): JWTPayload | null {
    try {
      return jwt.verify(token, JWT_SECRET) as JWTPayload
    } catch (error) {
      return null
    }
  }

  static generateResetToken(userId: string): string {
    return jwt.sign({ userId, type: "reset" }, JWT_SECRET, { expiresIn: "1h" })
  }

  static verifyResetToken(token: string): { userId: string } | null {
    try {
      const payload = jwt.verify(token, JWT_SECRET) as any
      if (payload.type === "reset") {
        return { userId: payload.userId }
      }
      return null
    } catch (error) {
      return null
    }
  }
}
