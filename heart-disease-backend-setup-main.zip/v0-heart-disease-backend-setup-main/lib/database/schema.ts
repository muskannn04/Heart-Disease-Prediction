export interface User {
  id: string
  email: string
  password: string
  firstName: string
  lastName: string
  role: "patient" | "doctor"
  isEmailVerified: boolean
  emailVerificationToken?: string
  passwordResetToken?: string
  passwordResetExpires?: Date
  createdAt: Date
  updatedAt: Date
  lastLogin?: Date
  loginAttempts: number
  lockUntil?: Date
}

export interface UserSession {
  id: string
  userId: string
  token: string
  expiresAt: Date
  createdAt: Date
  ipAddress?: string
  userAgent?: string
}

export interface Prediction {
  id: string
  userId: string
  patientData: {
    age: number
    sex: number
    chestPainType: number
    restingBP: number
    cholesterol: number
    fastingBS: number
    restingECG: number
    maxHR: number
    exerciseAngina: number
    oldpeak: number
    stSlope: number
  }
  prediction: {
    riskLevel: "Low" | "Medium" | "High"
    probability: number
    model: string
  }
  createdAt: Date
}

// In-memory storage for demo (replace with actual database)
export const users: User[] = []
export const sessions: UserSession[] = []
export const predictions: Prediction[] = []
