import { type User, type UserSession, type Prediction, users, sessions, predictions } from "./schema"
import { v4 as uuidv4 } from "uuid"

export class DatabaseOperations {
  // User operations
  static async createUser(userData: Omit<User, "id" | "createdAt" | "updatedAt" | "loginAttempts">): Promise<User> {
    const user: User = {
      ...userData,
      id: uuidv4(),
      createdAt: new Date(),
      updatedAt: new Date(),
      loginAttempts: 0,
    }
    users.push(user)
    return user
  }

  static async findUserByEmail(email: string): Promise<User | null> {
    return users.find((user) => user.email === email) || null
  }

  static async findUserById(id: string): Promise<User | null> {
    return users.find((user) => user.id === id) || null
  }

  static async updateUser(id: string, updates: Partial<User>): Promise<User | null> {
    const userIndex = users.findIndex((user) => user.id === id)
    if (userIndex === -1) return null

    users[userIndex] = { ...users[userIndex], ...updates, updatedAt: new Date() }
    return users[userIndex]
  }

  // Session operations
  static async createSession(sessionData: Omit<UserSession, "id" | "createdAt">): Promise<UserSession> {
    const session: UserSession = {
      ...sessionData,
      id: uuidv4(),
      createdAt: new Date(),
    }
    sessions.push(session)
    return session
  }

  static async findSessionByToken(token: string): Promise<UserSession | null> {
    return sessions.find((session) => session.token === token && session.expiresAt > new Date()) || null
  }

  static async deleteSession(token: string): Promise<boolean> {
    const sessionIndex = sessions.findIndex((session) => session.token === token)
    if (sessionIndex === -1) return false

    sessions.splice(sessionIndex, 1)
    return true
  }

  // Prediction operations
  static async createPrediction(predictionData: Omit<Prediction, "id" | "createdAt">): Promise<Prediction> {
    const prediction: Prediction = {
      ...predictionData,
      id: uuidv4(),
      createdAt: new Date(),
    }
    predictions.push(prediction)
    return prediction
  }

  static async getUserPredictions(userId: string): Promise<Prediction[]> {
    return predictions.filter((prediction) => prediction.userId === userId)
  }
}
