// Model management system for loading and managing ML models
export interface ModelConfig {
  name: string
  type: "random_forest" | "svm" | "logistic_regression" | "neural_network"
  version: string
  features: string[]
  accuracy: number
  isActive: boolean
}

export interface PredictionInput {
  age: number
  sex: number // 0: female, 1: male
  cp: number // chest pain type (0-3)
  trestbps: number // resting blood pressure
  chol: number // serum cholesterol
  fbs: number // fasting blood sugar > 120 mg/dl (0: false, 1: true)
  restecg: number // resting electrocardiographic results (0-2)
  thalach: number // maximum heart rate achieved
  exang: number // exercise induced angina (0: no, 1: yes)
  oldpeak: number // ST depression induced by exercise
  slope: number // slope of peak exercise ST segment (0-2)
  ca: number // number of major vessels colored by fluoroscopy (0-3)
  thal: number // thalassemia (1: normal, 2: fixed defect, 3: reversible defect)
}

export interface PredictionResult {
  prediction: number // 0: no disease, 1: disease
  probability: number
  riskLevel: "Low" | "Medium" | "High"
  confidence: number
  modelUsed: string
  timestamp: string
}

export class ModelManager {
  private models: Map<string, ModelConfig> = new Map()

  constructor() {
    this.initializeModels()
  }

  private initializeModels() {
    // Initialize available models
    const models: ModelConfig[] = [
      {
        name: "Random Forest",
        type: "random_forest",
        version: "1.0.0",
        features: [
          "age",
          "sex",
          "cp",
          "trestbps",
          "chol",
          "fbs",
          "restecg",
          "thalach",
          "exang",
          "oldpeak",
          "slope",
          "ca",
          "thal",
        ],
        accuracy: 0.87,
        isActive: true,
      },
      {
        name: "Support Vector Machine",
        type: "svm",
        version: "1.0.0",
        features: [
          "age",
          "sex",
          "cp",
          "trestbps",
          "chol",
          "fbs",
          "restecg",
          "thalach",
          "exang",
          "oldpeak",
          "slope",
          "ca",
          "thal",
        ],
        accuracy: 0.84,
        isActive: true,
      },
      {
        name: "Logistic Regression",
        type: "logistic_regression",
        version: "1.0.0",
        features: [
          "age",
          "sex",
          "cp",
          "trestbps",
          "chol",
          "fbs",
          "restecg",
          "thalach",
          "exang",
          "oldpeak",
          "slope",
          "ca",
          "thal",
        ],
        accuracy: 0.82,
        isActive: true,
      },
    ]

    models.forEach((model) => {
      this.models.set(model.type, model)
    })
  }

  getAvailableModels(): ModelConfig[] {
    return Array.from(this.models.values()).filter((model) => model.isActive)
  }

  getModel(type: string): ModelConfig | undefined {
    return this.models.get(type)
  }

  preprocessInput(input: PredictionInput): number[] {
    // Convert input object to feature array
    return [
      input.age,
      input.sex,
      input.cp,
      input.trestbps,
      input.chol,
      input.fbs,
      input.restecg,
      input.thalach,
      input.exang,
      input.oldpeak,
      input.slope,
      input.ca,
      input.thal,
    ]
  }

  // Simulate model prediction (in real implementation, this would call actual ML models)
  async predict(input: PredictionInput, modelType = "random_forest"): Promise<PredictionResult> {
    const model = this.getModel(modelType)
    if (!model) {
      throw new Error(`Model ${modelType} not found`)
    }

    // Preprocess input
    const features = this.preprocessInput(input)

    // Simulate prediction logic (replace with actual model inference)
    const prediction = this.simulateModelPrediction(features, modelType)
    const probability = Math.random() * 0.4 + prediction * 0.6 // Simulate probability

    // Determine risk level based on probability
    let riskLevel: "Low" | "Medium" | "High"
    if (probability < 0.3) riskLevel = "Low"
    else if (probability < 0.7) riskLevel = "Medium"
    else riskLevel = "High"

    return {
      prediction,
      probability: Math.round(probability * 100) / 100,
      riskLevel,
      confidence: model.accuracy,
      modelUsed: model.name,
      timestamp: new Date().toISOString(),
    }
  }

  private simulateModelPrediction(features: number[], modelType: string): number {
    // Simple simulation based on key risk factors
    const age = features[0]
    const chol = features[4]
    const thalach = features[7]
    const oldpeak = features[9]

    let riskScore = 0

    // Age factor
    if (age > 60) riskScore += 0.3
    else if (age > 45) riskScore += 0.2

    // Cholesterol factor
    if (chol > 240) riskScore += 0.25
    else if (chol > 200) riskScore += 0.15

    // Heart rate factor
    if (thalach < 120) riskScore += 0.2

    // ST depression factor
    if (oldpeak > 2) riskScore += 0.25
    else if (oldpeak > 1) riskScore += 0.15

    // Add some model-specific variation
    const modelVariation = {
      random_forest: 0.05,
      svm: -0.03,
      logistic_regression: 0.02,
    }

    riskScore += modelVariation[modelType as keyof typeof modelVariation] || 0

    return riskScore > 0.5 ? 1 : 0
  }

  validateInput(input: any): { isValid: boolean; errors: string[] } {
    const errors: string[] = []
    const requiredFields = [
      "age",
      "sex",
      "cp",
      "trestbps",
      "chol",
      "fbs",
      "restecg",
      "thalach",
      "exang",
      "oldpeak",
      "slope",
      "ca",
      "thal",
    ]

    // Check required fields
    requiredFields.forEach((field) => {
      if (input[field] === undefined || input[field] === null) {
        errors.push(`${field} is required`)
      }
    })

    // Validate ranges
    if (input.age && (input.age < 0 || input.age > 120)) {
      errors.push("Age must be between 0 and 120")
    }

    if (input.sex && ![0, 1].includes(input.sex)) {
      errors.push("Sex must be 0 (female) or 1 (male)")
    }

    if (input.cp && ![0, 1, 2, 3].includes(input.cp)) {
      errors.push("Chest pain type must be 0, 1, 2, or 3")
    }

    if (input.trestbps && (input.trestbps < 80 || input.trestbps > 250)) {
      errors.push("Resting blood pressure must be between 80 and 250")
    }

    if (input.chol && (input.chol < 100 || input.chol > 600)) {
      errors.push("Cholesterol must be between 100 and 600")
    }

    return {
      isValid: errors.length === 0,
      errors,
    }
  }
}

// Singleton instance
export const modelManager = new ModelManager()
