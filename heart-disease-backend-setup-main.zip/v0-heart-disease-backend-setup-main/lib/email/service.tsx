// Email service for password recovery and verification
// In production, replace with actual email service like SendGrid, Nodemailer, etc.

export interface EmailTemplate {
  to: string
  subject: string
  html: string
  text: string
}

export class EmailService {
  static async sendEmail(template: EmailTemplate): Promise<boolean> {
    try {
      // Mock email sending - replace with actual email service
      console.log("📧 Email would be sent:", {
        to: template.to,
        subject: template.subject,
        preview: template.text.substring(0, 100) + "...",
      })

      // Simulate email sending delay
      await new Promise((resolve) => setTimeout(resolve, 1000))

      return true
    } catch (error) {
      console.error("Email sending failed:", error)
      return false
    }
  }

  static generatePasswordResetEmail(email: string, resetToken: string, firstName: string): EmailTemplate {
    const resetUrl = `${process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000"}/auth/reset-password?token=${resetToken}`

    return {
      to: email,
      subject: "Reset Your Password - Heart Disease Detection System",
      html: `
        <div style="max-width: 600px; margin: 0 auto; font-family: Arial, sans-serif;">
          <h2>Password Reset Request</h2>
          <p>Hello ${firstName},</p>
          <p>We received a request to reset your password for your Heart Disease Detection System account.</p>
          <p>Click the button below to reset your password:</p>
          <div style="text-align: center; margin: 30px 0;">
            <a href="${resetUrl}" style="background-color: #007bff; color: white; padding: 12px 24px; text-decoration: none; border-radius: 4px; display: inline-block;">
              Reset Password
            </a>
          </div>
          <p>If the button doesn't work, copy and paste this link into your browser:</p>
          <p style="word-break: break-all; color: #666;">${resetUrl}</p>
          <p>This link will expire in 1 hour for security reasons.</p>
          <p>If you didn't request this password reset, please ignore this email.</p>
          <hr style="margin: 30px 0; border: none; border-top: 1px solid #eee;">
          <p style="color: #666; font-size: 12px;">Heart Disease Detection System</p>
        </div>
      `,
      text: `
        Password Reset Request
        
        Hello ${firstName},
        
        We received a request to reset your password for your Heart Disease Detection System account.
        
        Please visit the following link to reset your password:
        ${resetUrl}
        
        This link will expire in 1 hour for security reasons.
        
        If you didn't request this password reset, please ignore this email.
        
        Heart Disease Detection System
      `,
    }
  }

  static generateEmailVerificationEmail(email: string, verificationToken: string, firstName: string): EmailTemplate {
    const verificationUrl = `${process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000"}/auth/verify-email?token=${verificationToken}`

    return {
      to: email,
      subject: "Verify Your Email - Heart Disease Detection System",
      html: `
        <div style="max-width: 600px; margin: 0 auto; font-family: Arial, sans-serif;">
          <h2>Welcome to Heart Disease Detection System!</h2>
          <p>Hello ${firstName},</p>
          <p>Thank you for registering with our Heart Disease Detection System. To complete your registration, please verify your email address.</p>
          <div style="text-align: center; margin: 30px 0;">
            <a href="${verificationUrl}" style="background-color: #28a745; color: white; padding: 12px 24px; text-decoration: none; border-radius: 4px; display: inline-block;">
              Verify Email
            </a>
          </div>
          <p>If the button doesn't work, copy and paste this link into your browser:</p>
          <p style="word-break: break-all; color: #666;">${verificationUrl}</p>
          <p>If you didn't create this account, please ignore this email.</p>
          <hr style="margin: 30px 0; border: none; border-top: 1px solid #eee;">
          <p style="color: #666; font-size: 12px;">Heart Disease Detection System</p>
        </div>
      `,
      text: `
        Welcome to Heart Disease Detection System!
        
        Hello ${firstName},
        
        Thank you for registering with our Heart Disease Detection System. To complete your registration, please verify your email address.
        
        Please visit the following link to verify your email:
        ${verificationUrl}
        
        If you didn't create this account, please ignore this email.
        
        Heart Disease Detection System
      `,
    }
  }
}
